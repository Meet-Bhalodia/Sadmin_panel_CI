<?php 
class Get_new_salon extends CI_Model{
    // public function get_salon(){

        protected $table = 'saloon';
        protected $primarykey = 'id';
        protected $allowedfleid = [
            'id',
            'name',
            'user_name',
            'mail',
            'mobile',
            'current_status'
        ];



        // return $this->db->get('saloon');
        // return $query->$result();
    // } 
}
?>