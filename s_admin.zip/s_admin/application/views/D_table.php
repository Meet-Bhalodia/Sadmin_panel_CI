
<style>
              a {
                display: block;
              }

              a.dropdown-item:hover {
                background-color: aliceblue;
                color: darkblue;
              }

              a.dropdown-item {
                /* background-color: aliceblue; */
                text-align: center;
                margin: 5%;
                padding: 3%;
              }

              .fixed-table-toolbar {
                display: contents;
              }

              .columns-right.btn-group.float-right {
                float: right;
              }

              .float-right.search.btn-group {
                float: right;
              }

              .bs-bars.float-left {
                display: inline-flex;
              }
            </style>
            <div class="content-wrapper">
              <section class="content-header">
                <h1>
                  <i class="fa fa-history" aria-hidden="true"></i> Appointment
                  <small>Control panel</small>
                </h1>
              </section>
              <section class="content" style="padding: 5%;">


                <div class="container-fluid">
                  <div id="toolbar" class="select" style="display: flex;">
                    <select class="form-control">
                      <option value="">Export Basic</option>
                      <option value="all">Export All</option>
                      <option value="selected">Export Selected</option>
                    </select>
                    <button class="btn btn-secondary" type="button" name="refresh" id="refresh" aria-label="Refresh"><i
                        class="fa fa-refresh" aria-hidden="true"></i></button>
                  </div>

                  <table class="table" id="table" data-show-refresh="true" data-pagination="true" data-toggle="table"
                    data-toolbar="#toolbar" data-show-export="true" data-search="true" data-side-pagination="server"
                    data-click-to-select="true" data-toolbar="#toolbar" data-show-toggle="true" data-show-columns="true"
                    data-side-pagination="server"
                    data-url="<?php echo base_url() . 'Viewappointment/GetAppointment'; ?>">

                  </table>
                </div>

                <script>
                  var $table = $('#table');


                  $(function () {

                    $('#toolbar').find('select').change(function () {
                      $table.bootstrapTable('destroy').bootstrapTable({
                        exportDataType: $(this).val(),
                        exportTypes: ['json', 'xml', 'csv', 'txt', 'sql', 'excel', 'pdf'],
                        columns: [
                          {
                            field: 'state',
                            checkbox: true,
                            visible: $(this).val() === 'selected'
                          },
                          {
                            field: 'ID',
                            title: 'sr.no'
                          }, {
                            field: 'name',
                            title: 'Salon_name'
                          }, {
                            field: 'username',
                            title: 'own_name'
                          }, {
                            field: 'mail',
                            title: 'email'
                          }, {
                            field: 'mobile',
                            title: 'mobile_no'
                          }, {
                            field: 'status',
                            title: 'Status'
                          }
                        ]
                      })
                    }).trigger('change')
                  }),

                    $("#refresh").click(function () {
                      $table.bootstrapTable('refresh', {
                        url: '<?php echo base_url() . 'Viewappointment/GetAppointment'; ?>'
                      });
                    });

                </script>




                <!-- change Appointment Status -->
                <script>
                  function changestatus($id, $status, $user_id) {

                    var app_data = {
                      'id': $id,
                      'status': $status,
                      'user_id': $user_id
                    };

                    $.ajax({
                      url: "<?php echo base_url(); ?>manageappointment/changestatus",
                      type: "POST",
                      dataType: "json",
                      data: app_data,
                      success: function (data) {
                        console.log(data);
                        jQuery('#refresh').click();
                      }
                    });
                    console.log($id);
                    console.log($status);
                    console.log();



                  }


                </script>

              </section>
            </div>