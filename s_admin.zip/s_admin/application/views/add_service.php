<div class="home-content">


  <div class="sales-boxes">
    <div class="recent-sales box">
      <!-- <div class="title">Recent Sales</div> -->
      <div class="sales-details">
        <!-- -------------------------------------------table ------------------------------------------->

        <style>
          a {
            display: block;
          }

          a.dropdown-item:hover {
            background-color: aliceblue;
            color: darkblue;
          }

          a.dropdown-item {
            /* background-color: aliceblue; */
            text-align: center;
            margin: 5%;
            padding: 3%;
          }

          .fixed-table-toolbar {
            display: contents;
          }

          .columns-right.btn-group.float-right {
            float: right;
          }

          .float-right.search.btn-group {
            float: right;
          }

          .bs-bars.float-left {
            display: inline-flex;
          }

          /* 23-02-2023 after */
          .__h1 {
            margin: 0;
          }
        </style>
        <div class="content-wrapper">
          <section class="content-header">
            <h1 class="__h1">
              <!-- <script src="https://cdn.lordicon.com/ritcuqlt.js"></script> -->
              <lord-icon
    src="https://cdn.lordicon.com/bxxnzvfm.json"
    trigger="hover"
    style="width:50px;height:50px;margin-bottom:-2%;">
</lord-icon>
              <!-- <i class="fa fa-history" aria-hidden="true"></i>  -->
              <small>Add Service</small>
              <button type="button" class="btn btn-primary btn-lg" style="float: right;"><a
                  href="<?php echo base_url(); ?>Add_service_c/add_employee" style="color:black;">
                  Add Service
                </a>
              </button>
            </h1>

          </section>
          <section class="content" style="padding: 5%;width: 100rem;">

            <div class="container-fluid">
              <div id="toolbar" class="select" style="display: flex;">
                <select class="form-control">
                  <option value="">Export Basic</option>
                  <option value="all">Export All</option>
                  <option value="selected">Export Selected</option>
                </select>
                <button class="btn btn-secondary" type="button" name="refresh" id="refresh" aria-label="Refresh"><i
                    class="fa fa-refresh" aria-hidden="true"></i></button>
              </div>

              <table style="width:100%" class="table" id="table" data-pagination="true" data-toggle="table"
                data-toolbar="#toolbar" data-show-export="true" data-side-pagination="server"
                data-click-to-select="true" data-toolbar="#toolbar" data-show-toggle="true" data-show-columns="true"
                data-side-pagination="server" data-url="<?php echo base_url() . 'Add_service_c/Get_service'; ?>">

              </table>
            </div>

            <script>
              var $table = $('#table');


              $(function () {

                $('#toolbar').find('select').change(function () {
                  $table.bootstrapTable('destroy').bootstrapTable({
                    exportDataType: $(this).val(),
                    exportTypes: ['json', 'xml', 'csv', 'txt', 'sql', 'excel', 'pdf'],
                    columns: [
                      {
                        field: 'state',
                        checkbox: true,
                        visible: $(this).val() === 'selected'
                      },
                      {
                        field: 'srno',
                        title: 'sr.no'
                      }, {
                        field: 'service_name',
                        title: 'service_name'
                      }, {
                        field: 'desciption',
                        title: 'description'
                      }, {
                        field: 'icon',
                        title: 'icon'
                      }
                      // ,{
                      //   field: 'mobile',
                      //   title: 'mobile_no'
                      // }
                      , {
                        field: 'status',
                        title: 'Status'
                      }
                    ]
                  })
                }).trigger('change')
              }),

                $("#refresh").click(function () {
                  $table.bootstrapTable('refresh', {
                    url: '<?php echo base_url() . 'Add_service_c/Get_service'; ?>'
                  });
                });

            </script>
          </section>
        </div>
        <!-- ---------------------------------table------------------------------------------------- -->
      </div>

    </div>

  </div>
  </section>