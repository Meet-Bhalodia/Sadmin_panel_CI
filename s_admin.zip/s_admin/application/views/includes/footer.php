<style>
  .pull-center{
    text-align:center!important;
  }

</style>
<footer class="main-footer">
  <div class="pull-center hidden-xs" style="height:50px!important;padding:1%;">
    <!-- <b style="">Barber's Hood</b> -->

    <span>&#169; by<b> Barber's Hood</b>. All Rights Reserved.</span>
  </div>
  <!-- <strong>Copyright &copy; 2014-2015 <a href="">CodeInsect</a>.</strong> All rights reserved. -->
</footer>




  <script>
    let sidebar = document.querySelector(".sidebar");
    let sidebarBtn = document.querySelector(".sidebarBtn");
    sidebarBtn.onclick = function () {
      sidebar.classList.toggle("active");
      if (sidebar.classList.contains("active")) {
        sidebarBtn.classList.replace("bx-menu", "bx-menu-alt-right");
      } else sidebarBtn.classList.replace("bx-menu-alt-right", "bx-menu");
    };
  </script>
  <!-- logout button event click/ -->
  <script>
    $("#logout").click(function (e) {
      e.preventDefault();
      $.ajax({
        url: "<?php echo base_url(); ?>Dashboard/logout",
        success: function (result) {
          document.location.reload(true)
        },
        error: function (result) {
          document.location.reload(true)
        }
      });
    });
  </script>






</body>

</html>