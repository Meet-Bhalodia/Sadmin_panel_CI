<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <title>BH Super Admin</title>
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/style.css" />

  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/js/main.js" />
  <!-- Boxicons CDN Link -->
  <link href="https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css" rel="stylesheet" />


  <!-- jquery -->
  <script src="https://code.jquery.com/jquery-3.6.3.min.js"
    integrity="sha256-pvPw+upLPUjgMXY0G+8O0xUf+/Im1MZjXxxgOcBQBXU=" crossorigin="anonymous"></script>


  <meta name="viewport" content="width=device-width, initial-scale=1.0" />

  <script src="https://code.jquery.com/jquery-3.6.3.min.js"
    integrity="sha256-pvPw+upLPUjgMXY0G+8O0xUf+/Im1MZjXxxgOcBQBXU=" crossorigin="anonymous"></script>

  <link href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css" rel="stylesheet" type="text/css" />

  <!-- font asw -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css"
    integrity="sha512-SzlrxWUlpfuzQ+pcUCosxcglQRNAq/DZjVsC0lE40xsADsfeQoEypE+enwcOiGjk/bSuGGKHEyjSoQ1zVisanQ=="
    crossorigin="anonymous" referrerpolicy="no-referrer" />

  <!-- lord icons -->
  <script src="https://cdn.lordicon.com/ritcuqlt.js"></script>


  <!-- Latest compiled and minified CSS -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/css/bootstrap.min.css">

  <!-- Optional theme -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/css/bootstrap-theme.min.css">

  <!-- Latest compiled and minified JavaScript -->
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/js/bootstrap.min.js"></script>


  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.js"></script>



  <!-- just added all required libraries from your example site -->
  <link rel="stylesheet" href="https://unpkg.com/bootstrap-table@1.21.2/dist/bootstrap-table.min.css">
  <script src="https://unpkg.com/tableexport.jquery.plugin/tableExport.min.js"></script>
  <script src="https://unpkg.com/bootstrap-table@1.17.1/dist/bootstrap-table.min.js"></script>
  <script src="https://unpkg.com/bootstrap-table@1.17.1/dist/extensions/export/bootstrap-table-export.min.js"></script>



  <style>
    .select,
    #locale {
      width: 100%;
    }

    .like {
      margin-right: 10px;
    }

    ol,
    ul {
      padding-left: 0 !important;
    }



    a {
      display: block;
    }

    a.dropdown-item:hover {
      background-color: aliceblue;
      color: darkblue;
    }

    a.dropdown-item {
      /* background-color: aliceblue; */
      text-align: center;
      margin: 5%;
      padding: 3%;
    }

    .fixed-table-toolbar {
      display: contents;
    }

    .columns-right.btn-group.float-right {
      float: right;
    }

    .float-right.search.btn-group {
      float: right;
    }

    .bs-bars.float-left {
      display: inline-flex;
    }
  </style>




  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.7.0/dist/sweetalert2.all.min.js"></script>
  <link href="https://cdn.jsdelivr.net/npm/sweetalert2@11.7.0/dist/sweetalert2.min.css" rel="stylesheet">
  </link>


  <style>
    .colored-toast.swal2-icon-success {
      background-color: #a5dc86 !important;
    }

    .colored-toast.swal2-icon-error {
      background-color: #f27474 !important;
    }

    .colored-toast.swal2-icon-warning {
      background-color: #f8bb86 !important;
    }

    .colored-toast.swal2-icon-info {
      background-color: #3fc3ee !important;
    }

    .colored-toast.swal2-icon-question {
      background-color: #87adbd !important;
    }

    .colored-toast .swal2-title {
      color: white;
    }

    .colored-toast .swal2-close {
      color: white;
    }

    .colored-toast .swal2-html-container {
      color: white;
    }
  </style>

  <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.5.0/Chart.min.js"></script>
  <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>

</head>

<body>
  <?php
  $path = $_SERVER['REQUEST_URI'];
  $active = str_replace('/ff', '', $path);
  // var_dump($active);
  ?>
  <div class="sidebar">
    <div class="logo-details">
      <i>
        <lord-icon src="https://cdn.lordicon.com/psdabgcj.json" trigger="hover" style="width:50px;height:50px">
        </lord-icon></i>
      <span class="logo_name">Barber's Hood</span>
    </div>
    <ul class="nav-links">
      <li>
        <a href="<?php echo base_url(); ?>Dashboard" class="<?php if ($active == '/Dashboard') {
             echo 'active';
           } ?>">
          <i>
            <!-- <lord-icon src="https://cdn.lordicon.com/sbgmyyba.json" trigger="hover" style="width:50px;height:50px">
            </lord-icon> -->
            <lord-icon src="https://cdn.lordicon.com/hursldrn.json" trigger="morph" style="width:50px;height:50px">
            </lord-icon>
          </i>
          <span class="links_name">Active Salons</span>
        </a>
      </li>
      <li>
        <a href="<?php echo base_url(); ?>Manage_salon_c" class="<?php if ($active == '/Manage_salon_c') {
             echo 'active';
           } ?>">
          <i>
            <lord-icon src="https://cdn.lordicon.com/wizuwpye.json" trigger="hover" style="width:50px;height:50px">
            </lord-icon>
          </i>
          <span class="links_name">Manage Salons</span>
        </a>
      </li>
      <li>
        <a href="<?php echo base_url(); ?>Rejected_salons" class="<?php if ($active == '/Rejected_salons') {
             echo 'active';
           } ?>">
          <i>
            <lord-icon src="https://cdn.lordicon.com/nokylann.json" trigger="morph" style="width:50px;height:50px">
            </lord-icon>
          </i>
          <span class="links_name">Rejected salons</span>
        </a>
      </li>
      <li>
        <a href="<?php echo base_url(); ?>Add_service_c" class="<?php if ($active == '/Add_service_c') {
             echo 'active';
           } ?>">
          <i>
            <lord-icon src="https://cdn.lordicon.com/edxgdhxu.json" trigger="hover" style="width:50px;height:50px">
            </lord-icon>

          </i>
          <span class="links_name">Add service</span>
        </a>
      </li>
      <li>
        <a href="<?php echo base_url(); ?>Report_c" class="<?php if ($active == '/Report_c') {
             echo 'active';
           } ?>">
          <i>
            <lord-icon src="https://cdn.lordicon.com/tbfrtmlu.json" trigger="hover" style="width:50px;height:50px">
            </lord-icon>
          </i>
          <span class="links_name">Reports</span>
        </a>
      </li>



      <li class="log_out" id="logout">
        <a href="#">
          <i>

            <lord-icon src="https://cdn.lordicon.com/qqedoixr.json" trigger="hover" style="width:50px;height:50px">
            </lord-icon>
          </i>
          <span class="links_name">logout</span>
        </a>
      </li>




      <!--  <li class="log_out">
        <a href="#">
          <button class="links_name" style="background-color: TRANSPARENT;border: 0;" id="logout">
          <lord-icon src="https://cdn.lordicon.com/qqedoixr.json" trigger="hover"
                style="width:50px;height:50px">
              </lord-icon><span class="links_name">logout</span></button>
        </a>
      </li> -->
    </ul>
  </div>
  <section class="home-section">
    <nav>
      <div class="sidebar-button">
        <i class="bx bx-menu sidebarBtn">
        </i>
        <span class="dashboard">Control Panel</span>
      </div>

      <div class="profile-details">
        <!-- <script src="https://cdn.lordicon.com/ritcuqlt.js"></script> -->
        <lord-icon class="lord__icon__" src="https://cdn.lordicon.com/dqxvvqzi.json" trigger="hover"
          style="width:50px;height:50px;">
        </lord-icon>
        <!-- <script src="https://cdn.lordicon.com/ritcuqlt.js"></script>
        <lord-icon src="https://cdn.lordicon.com/bhfjfgqz.json" trigger="hover" style="width:50px;height:50px">
        </lord-icon> -->
        <span class="admin_name">Meet Bhalodia</span>

      </div>
    </nav>