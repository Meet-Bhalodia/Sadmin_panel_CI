<div class="home-content">

    <div class="sales-boxes">
        <div class="recent-sales box">
            <!-- <div class="title">Recent Sales</div> -->
            <div class="sales-details">
                <!-- -------------------------------------------table ------------------------------------------->
                <style>
                    a {
                        display: block;
                    }

                    a.dropdown-item:hover {
                        background-color: aliceblue;
                        color: darkblue;
                    }

                    a.dropdown-item {
                        /* background-color: aliceblue; */
                        text-align: center;
                        margin: 5%;
                        padding: 3%;
                    }

                    .fixed-table-toolbar {
                        display: contents;
                    }

                    .columns-right.btn-group.float-right {
                        float: right;
                    }

                    .float-right.search.btn-group {
                        float: right;
                    }

                    .bs-bars.float-left {
                        display: inline-flex;
                    }

                    /* 23-02-2023 after */
                    .__h1 {
                        margin: 0;
                    }

                    @media (max-width: 330px) {
                .content{
                        padding: 0!important;
                    }
                    #myChart{
                        width:286px !important;
                    }
                    }
                </style>

                <div class="content-wrapper">
                    <section class="content-header">
                        <h1 class="__h1">
                            <lord-icon src="https://cdn.lordicon.com/oegrrprk.json" trigger="hover"
                                style="width:50px;height:50px;margin-bottom:-2%;">
                            </lord-icon>
                            <small>Reports</small>
                        </h1>
                    </section>
                    <section class="content" style="padding: 5%;width: 100rem;">

                        <div class="container-fluid">

                            <!-- salon wise total wise profit -->
                            <!-- SELECT SUM(`Total_Amount`),`saloon`.`name` FROM `appointment` LEFT JOIN `employee` ON `appointment`.`emp_id` = `employee`.`id` LEFT JOIN `saloon` ON `employee`.`saloon_id`=`saloon`.`id` GROUP BY `saloon`.`name`; -->
                            <!-- salon wise employ wise total profit -->
                            <!-- SELECT SUM(`Total_Amount`),`employee`.`username`,`saloon`.`name` FROM `appointment` LEFT JOIN `employee` ON `appointment`.`emp_id` = `employee`.`id` LEFT JOIN `saloon` ON `employee`.`saloon_id`=`saloon`.`id` GROUP BY `employee`.`id`; -->
                            <!-- chart starts -->
                            <canvas id="myChart" style="width:100%;max-width:600px"></canvas>
                            <script>
                                // name of salon
                                var xValues = [
                                    <?php foreach ($all_salon_name as $value) {
                                        // echo $value,"";
                                        echo "'" . $value['name'] . "',";
                                    } ?>];
                                // earning of salon
                                var yValues = [<?php foreach ($salon_total as $value_) {
                                    echo "'" . $value_['total'] . "',";
                                } ?>0];
                                var barColors = ["red", "green", "blue", "orange", "brown"];
                                console.log("chart_2")
                                new Chart("myChart", {
                                    type: "bar",
                                    data: {
                                        labels: xValues,
                                        datasets: [{
                                            backgroundColor: barColors,
                                            data: yValues
                                        }]
                                    },
                                    options: {
                                        legend: { display: false },
                                        title: {
                                            display: true,
                                            text: "Salon Earnings"
                                        }
                                    }
                                });
                            </script>

                            <!-- chart ends -->

                        </div>


                    </section>
                </div>
                <!-- ---------------------------------table------------------------------------------------- -->
            </div>

        </div>

    </div>
    </section>