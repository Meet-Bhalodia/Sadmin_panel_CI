<div class="home-content">

  <div class="sales-boxes">
    <div class="recent-sales box">
      <!-- <div class="title">Recent Sales</div> -->
      <div class="sales-details">
        <!-- -------------------------------------------table ------------------------------------------->

        <style>
          a {
            display: block;
          }

          a.dropdown-item:hover {
            background-color: aliceblue;
            color: darkblue;
          }

          a.dropdown-item {
            /* background-color: aliceblue; */
            text-align: center;
            margin: 5%;
            padding: 3%;
          }

          .fixed-table-toolbar {
            display: contents;
          }

          .columns-right.btn-group.float-right {
            float: right;
          }

          .float-right.search.btn-group {
            float: right;
          }

          .bs-bars.float-left {
            display: inline-flex;
          }

          /* 23-02-2023 after */
          .__h1 {
            margin: 0;
          }
        </style>
        <div class="content-wrapper">
          <section class="content-header">
            <h1 class="__h1">
              <!-- <script src="https://cdn.lordicon.com/ritcuqlt.js"></script>
                  <lord-icon class="lord__icon__" src="https://cdn.lordicon.com/dqxvvqzi.json" trigger="hover" style="width:50px;height:50px;position: relative;
  top: 9px;color:black;">
                  </lord-icon> -->
              <!-- <i class="fa fa-history" aria-hidden="true"></i> -->
              <lord-icon src="https://cdn.lordicon.com/pwtxdzer.json" trigger="hover"
                style="width:50px;height:50px;margin-bottom:-2%;">
              </lord-icon>
              <small>Manage Salons</small>
            </h1>
          </section>
          <section class="content" style="padding: 5%;width: 100rem;">

            <div class="container-fluid">
              <div id="toolbar" class="select" style="display: flex;">
                <select class="form-control">
                  <option value="">Export Basic</option>
                  <option value="all">Export All</option>
                  <option value="selected">Export Selected</option>
                </select>
                <button class="btn btn-secondary" type="button" name="refresh" id="refresh" aria-label="Refresh"><i
                    class="fa fa-refresh" aria-hidden="true"></i></button>
              </div>

              <table style="width:100%" class="table" id="table" data-pagination="true" data-toggle="table"
                data-toolbar="#toolbar" data-show-export="true" data-side-pagination="server"
                data-click-to-select="true" data-toolbar="#toolbar" data-show-toggle="true" data-show-columns="true"
                data-side-pagination="server" data-url="<?php echo base_url() . 'Manage_salon_c/Get_new_salons'; ?>">

              </table>
            </div>

            <script>
              var $table = $('#table');


              $(function () {

                $('#toolbar').find('select').change(function () {
                  $table.bootstrapTable('destroy').bootstrapTable({
                    exportDataType: $(this).val(),
                    exportTypes: ['json', 'xml', 'csv', 'txt', 'sql', 'excel', 'pdf'],
                    columns: [
                      {
                        field: 'state',
                        checkbox: true,
                        visible: $(this).val() === 'selected'
                      },
                      {
                        field: 'srno',
                        title: 'Sr.no'
                      }, {
                        field: 'name',
                        title: 'Salon_name'
                      }, {
                        field: 'username',
                        title: 'Owner_name'
                      }, {
                        field: 'mail',
                        title: 'Email'
                      }, {
                        field: 'mobile',
                        title: 'Mobile_no'
                      }, {
                        field: 'status',
                        title: 'Manage'
                      }
                    ]
                  })
                }).trigger('change')
              }),

                $("#refresh").click(function () {
                  $table.bootstrapTable('refresh', {
                    url: '<?php echo base_url() . 'Manage_salon_c/Get_new_salons'; ?>'
                  });
                });

            </script>
          </section>
        </div>
        <!-- ---------------------------------table------------------------------------------------- -->
      </div>

    </div>

  </div>
  </section>

  <!-- change Salon Status -->
  <script>
    function changestatus($id, $status) {

      var app_data = {
        'id': $id,
        'status': $status
      };

      $.ajax({
        url: "<?php echo base_url(); ?>Manage_salon_c/changestatus",
        type: "POST",
        dataType: "json",
        data: app_data,
        success: function (data) {
          console.log(data.status);
          $('#refresh').click();

          // $('#refresh').('click', function () {
          //   console.log("this is the click");
          //   return false;
          // });

        }, error: function (data) {

          console.log("error");
        }
      });
      console.log($id);
      console.log($status);
      // console.log();



    }



  </script>