<?php
// defined('BASEPATH') OR exit('No direct script access allowed');

class Report_c extends CI_Controller
{
	public function index()
	{
		// data coming

		if(isset($_SESSION['id'])){
			// $new_salon_data = $this->db->query('select id,name,username,mail,mobile,current_status from saloon where active=0 ORDER BY id');
			// $response['new_salon_data'] = $new_salon_data->result_array();
			// var_dump($response);
			
			$all_salon_name = $this->db->query('SELECT `name` FROM `saloon`');
			$response['all_salon_name'] = $all_salon_name->result_array();
			// var_dump($response);

			// $salon_total = $this->db->query('SELECT SUM(`Total_Amount`) FROM `appointment` LEFT JOIN `employee` ON `appointment`.`emp_id` = `employee`.`id` LEFT JOIN `saloon` ON `employee`.`saloon_id`=`saloon`.`id` GROUP BY `saloon`.`name`;');
			$salon_total = $this->db->query('SELECT SUM(`Total_Amount`) as total FROM `appointment` LEFT JOIN `employee` ON `appointment`.`emp_id` = `employee`.`id` LEFT JOIN `saloon` ON `employee`.`saloon_id`=`saloon`.`id` GROUP BY `saloon`.`name` ORDER BY `Total_Amount` ASC;');
			// SELECT SUM(`Total_Amount`) FROM `appointment` LEFT JOIN `employee` ON `appointment`.`emp_id` = `employee`.`id` LEFT JOIN `saloon` ON `employee`.`saloon_id`=`saloon`.`id` GROUP BY `saloon`.`name` ORDER BY `Total_Amount` ASC;

			$response['salon_total'] = $salon_total->result_array();
			// var_dump($response);



			$this->load->view('includes/header');
			$this->load->view('reports',$response);
			$this->load->view('includes/footer');
		}
		else{
			$this->load->view('login');
		}

	}
	// 

    
    
	// public function GetAppointment()
	// 
	public function Get_new_salons()
	{
		if (isset($_SESSION['id'])) {
            echo "hello";




		}
		 else {
			redirect('/', 'refresh');
		}


	}
	// 


	public function logout()
	{
		if(isset($_SESSION['id'])){
			unset($_SESSION['id']);
		}else{
			redirect('/','refresh');
		}

		return "Logout";

	}

// 
}