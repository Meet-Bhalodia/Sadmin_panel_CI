<?php
// defined('BASEPATH') OR exit('No direct script access allowed');

class Add_service_c extends CI_Controller
{
	public function index()
	{
		// data coming

		if(isset($_SESSION['id'])){
			$salon_data = $this->db->query('SELECT id,service_name,desciption,icon FROM `services`');
			$response['salon_data'] = $salon_data->result_array();
            // var_dump($response);
			$this->load->view('includes/header');
			$this->load->view('add_service', $response);
			$this->load->view('includes/footer');
		}
		else{
			$this->load->view('login');
		}
		
		// var_dump($response);

	}
	// 

	// public function GetAppointment()
	public function Get_service()
	{
		if (isset($_SESSION['id'])) {

			// $salon_id = $_SESSION['id'];
			
			$all_data = $this->db->query('SELECT id,service_name,desciption,icon,active FROM `services`')->result();
			$status = "asfs";
			$sr_no = 1;
			foreach ($all_data as $row) {
				// var_dump($row);
				// die();
				if ($row->active == 1) {
					$status = "<i class='ionicons ion-checkmark'></i>";
				} else if ($row->active == 2) {
					$status = "<i class='ionicons ion-close'></i>";
				} else {
					$status = "<button type='button' class='btn btn-success' onclick='changestatus($row->id,1)'>Approve</button>
					<button type='button' class='btn btn-danger' onclick='changestatus($row->id,2)'>Reject</button>";
				}
				$tempRow['status'] = $status;


				$tempRow['srno'] = $sr_no++;
				$tempRow['service_name']= $row->service_name ;
				$tempRow['desciption']= $row->desciption;
				$tempRow['icon']= $row->icon;
				// $tempRow['mobile']= $row->mobile;
				
				

				$rows[] = $tempRow;
			}



			$bulkData['rows'] = $rows;
			print_r(json_encode($bulkData));
		}
		 else {
			redirect('/', 'refresh');
		}


	}

	
    public function add_employee()
	{
		if(isset($_SESSION['id'])){
			// $salon_id = $_SESSION['id'];
			// $salon_info['salon_info'] = $this -> db -> select('name,username,mail,logo') -> where('id', $salon_id) -> get('saloon') ->result();
			$this->load->view('includes/header');
			$this->load->view('new_service');
			$this->load->view('includes/footer');
		}else{
			redirect('/','refresh');
		}
	}

    public function Save_Service()
    {
        if(isset($_SESSION['id'])){
            $salon_id = $_SESSION['id'];
            $url=base_url()."Add_service_c/";
            if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                    // $emp_name=$_POST['Service'];
                    $service_name=$_POST['service'];
                    $description=$_POST['description'];

                    $zname_clean = preg_replace('/\s*/', '', $service_name);
                    $zname_cleann = strtolower($zname_clean);
                    // echo $zname_cleann;
                    // die();

                    $image_file = $_FILES["image"];
                    $ext = strtolower(pathinfo($image_file["name"], PATHINFO_EXTENSION));
                    $image_store_path= "assets/icons/".$zname_cleann.".".$ext;
                    //  /Admin/assets/images/icon/
                    move_uploaded_file(
                        $image_file["tmp_name"],
                           $image_store_path
                    );



                    $imagename=$zname_cleann.".".$ext;
                    $data = array(
                                            'service_name' => $service_name,
                                            'desciption' => $description,
                                            'icon' => $imagename
                                            // 'active' => "1",
                                        );

                  $this->db->insert('services',$data);
                    header("Location: $url");

            }else{

                header("Location: $url");

            }
        }else{
            redirect('/','refresh');
        }



    }

	public function logout()
	{
		if(isset($_SESSION['id'])){
			unset($_SESSION['id']);
		}else{
			redirect('/','refresh');
		}

		return "Logout";

	}

// 
}