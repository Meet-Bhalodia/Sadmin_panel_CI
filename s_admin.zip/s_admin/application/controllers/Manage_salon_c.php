<?php
// defined('BASEPATH') OR exit('No direct script access allowed');

class Manage_salon_c extends CI_Controller
{
	public function index()
	{
		// data coming

		if (isset($_SESSION['id'])) {
			$new_salon_data = $this->db->query('select id,name,username,mail,mobile,current_status from saloon where active=0 ORDER BY id');
			$response['new_salon_data'] = $new_salon_data->result_array();
			// var_dump($response);




			$sql = "SELECT * FROM `saloon` WHERE `active` = 1";
			$result = $this->db->query($sql)->result();
			// var_dump($result);




			$this->load->view('includes/header');
			$this->load->view('manage_salons', $response);
			$this->load->view('includes/footer');
		} else {
			$this->load->view('login');
		}

	}
	// 



	// public function GetAppointment()
	// 
	public function Get_new_salons()
	{
		if (isset($_SESSION['id'])) {

			// $salon_id = $_SESSION['id'];

			$new_salon = $this->db->query('select id,name,username,mail,mobile,active from saloon where active=0 ORDER BY id')->result();
			$status = "asfs";
			$sr_no = 1;
			foreach ($new_salon as $row) {
				// var_dump($row);
				// die();
				if ($row->active == 1) {
					$status = "<i class='ionicons ion-checkmark'></i>";
				} else if ($row->active == 2) {
					$status = "<i class='ionicons ion-close'></i>";
				} else {
					$status = "<button type='button' class='btn btn-success' id='1' onclick='changestatus($row->id,1)'>Approve</button>
					<button type='button' class='btn btn-danger' id='2' onclick='changestatus($row->id,2)'>Reject</button>";
				}
				$tempRow['status'] = $status;


				$tempRow['srno'] = $sr_no++;
				$tempRow['name'] = $row->name;
				$tempRow['username'] = $row->username;
				$tempRow['mail'] = $row->mail;
				$tempRow['mobile'] = $row->mobile;

				$rows[] = $tempRow;
			}



			$bulkData['rows'] = $rows;
			print_r(json_encode($bulkData));
		} else {
			redirect('/', 'refresh');
		}


	}
	// 


	// change status to approve or reject


	public function changestatus()
	{
		if (isset($_SESSION['id'])) {
			$id = $this->input->post('id');
			$status = $this->input->post('status');
			// var_dump($id);
			// var_dump($status);
			//   $id  = $this->input->post('id');
			//   $status = $this->input->post('status');
			//   $user_id = $this->input->post('user_id');
			// 	var_dump($id);

			// $approve = $this->input->post('id');

			// $approve = $this->db->query("UPDATE `saloon` SET `acitve`=1 WHERE id=3");
			// $reject = $this->db->query("UPDATE `saloon` SET `acitve`=2 WHERE id=3");	

			$update_status = array('active' => $status);
			$this->db->where('id', $id);
			$this->db->update('saloon', $update_status);
			// $response['update_status'] = $update_status->result_array();
			header('Content-Type: application/json');
			echo json_encode(true);
		} else {
			redirect('/', 'refresh');
		}

	}



	// 

	public function logout()
	{
		if (isset($_SESSION['id'])) {
			unset($_SESSION['id']);
		} else {
			redirect('/', 'refresh');
		}

		return "Logout";

	}

// 
}