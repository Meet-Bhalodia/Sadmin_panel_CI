<?php
defined('BASEPATH') or exit('No direct script access allowed');
header('Access-Control-Allow-Origin: *');
header("Access-Control-Allow-Methods: GET, OPTIONS");

class app_rej_salon_c extends CI_Controller
{

    public function changestatus(){
      if(isset($_SESSION['id'])){
        $id  = $this->input->post('id');
        $status = $this->input->post('status');
        $user_id = $this->input->post('user_id');


        $update_status = array('status'=>$status);
        $this->db->where('id', $id);
        $this->db->update('appointment', $update_status);

        //notification send to user
                require_once(APPPATH.'third_party/pusher/pusher-php-server/src/Pusher.php');
                require_once(APPPATH.'third_party/pusher/pusher-php-server/src/PusherException.php');
                require_once(APPPATH.'third_party/pusher/pusher-php-server/src/PusherInstance.php');
                $options = array(
                    'cluster' => 'ap2'
                );
                $pusher = new Pusher\Pusher(
                    '1afa74497d921dca053d',
                    'a0fef5f314fc54820bd5',
                    '1544217',
                    $options
                );

                // if($message and $data['to_id']){
                    if($status == 1){
                        $send['message'] = "Your Appointment Approved....";
                        $send['link'] = "123";
                        $send['status'] = true;
                    }else{
                        $send['message'] = "Your Appointment Rejected !";
                        $send['link'] = "123";
                        $send['status'] = false;
                    }

                $mychannel = $user_id."_u";

                $respo = $pusher->trigger($mychannel, 'my-event', $send);


        header('Content-Type: application/json');
        echo json_encode(true);
      }else{
        redirect('/','refresh');
      }

    }



}
