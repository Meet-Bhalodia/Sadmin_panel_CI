<?php
// defined('BASEPATH') OR exit('No direct script access allowed');

class Rejected_salons extends CI_Controller
{
	public function index()
	{
		// data coming

		if(isset($_SESSION['id'])){
			$salon_data = $this->db->query('select id,name,username,mail,mobile,current_status from saloon where active=1 ORDER BY id');
			$response['salon_data'] = $salon_data->result_array();

			$this->load->view('includes/header');
			$this->load->view('rejected_salons', $response);
			$this->load->view('includes/footer');
		}
		else{
			$this->load->view('login');
		}
		
		// var_dump($response);

	}
	// 

	// public function GetAppointment()
	public function Get_salons_rejected()
	{
		if (isset($_SESSION['id'])) {

			// $salon_id = $_SESSION['id'];
			
			$all_data = $this->db->query('select id,name,username,mail,mobile,active from saloon where active=2 ORDER BY id')->result();
			$status = "asfs";
			$sr_no = 1;
			foreach ($all_data as $row) {
				// var_dump($row);
				// die();
				if ($row->active == 1) {
					$status = "<i class='ionicons ion-checkmark'></i>";
				} else if ($row->active == 2) {
					$status = "<i class='ionicons ion-close'></i>";
				} else {
					$status = "<button type='button' class='btn btn-success' onclick='changestatus($row->id,1)'>Approve</button>
					<button type='button' class='btn btn-danger' onclick='changestatus($row->id,2)'>Reject</button>";
				}
				$tempRow['status'] = $status;


				$tempRow['srno'] = $sr_no++;
				$tempRow['name']= $row->name ;
				$tempRow['username']= $row->username;
				$tempRow['mail']= $row->mail;
				$tempRow['mobile']= $row->mobile;
				
				

				$rows[] = $tempRow;
			}



			$bulkData['rows'] = $rows;
			print_r(json_encode($bulkData));
		}
		 else {
			redirect('/', 'refresh');
		}


	}

	


	public function logout()
	{
		if(isset($_SESSION['id'])){
			unset($_SESSION['id']);
		}else{
			redirect('/','refresh');
		}

		return "Logout";

	}

// 
}