<?php
// defined('BASEPATH') or exit('No direct script access allowed');
// header('Access-Control-Allow-Origin: *');
// header("Access-Control-Allow-Methods: GET, OPTIONS");



class Login extends CI_Controller
{
	public function index()
	{
		if(isset($_SESSION['id'])){
			redirect('Dashboard','redirect');
		}
		else{
			$this->load->view('login');
		}
	}

	public function checklogin(){
		
		
		$user_name = $this->input->post('user_name');
		$pass = $this->input->post('user_password');

		$this->db->where('username', $user_name);
		$query = $this->db->get('admin');

		if ($query->num_rows() > 0) {
			$data = $query->result_array();
			if (password_verify($pass, $data[0]["password"])){
				$_SESSION['id'] = $data[0]["id"];
				redirect('Dashboard', 'refresh');
			} else {
				$this->session->set_flashdata('status', true);
				$this->session->set_flashdata('message', 'Invalid Creditional!');
				redirect('/', 'refresh');
				
				// echo "11";
			}
		} else {
			$this->session->set_flashdata('status', true);
			$this->session->set_flashdata('message', 'Your are not Admin.');
			redirect('/', 'refresh');
		}

	}

}