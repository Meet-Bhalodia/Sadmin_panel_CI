<?php
defined('BASEPATH') OR exit('No direct script access allowed');

// $route['Login'] = 'Login';

$route['/'] = 'Login';
$route['manage_salons'] = 'Manage_salon_c';
$route['add_service'] = 'Add_service_c';
$route['reports'] = 'Report_c';
$route['new_service'] = 'Add_service_c/add_employee';
$route['rejected_salons'] = 'Rejected_salons';
// $route['login/checklogin'] = 'Login/checklogin';
$route['Dashboard']= 'dashboard';
$route['managesalon'] = 'App_rej_salon_c/changestatus';
$route['default_controller'] = 'Login';
// $route['404_override'] = '';
// $route['translate_uri_dashes'] = FALSE;
