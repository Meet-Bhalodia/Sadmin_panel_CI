-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Mar 07, 2023 at 05:37 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.0.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `u539587596_salon`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(2) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(200) NOT NULL,
  `create_on` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`, `create_on`) VALUES
(1, 'meet', '$2y$10$mU7vTnLjvxDrFnzOMBtFYu0oLO6rNRPyRSXd9oGnig.DSnjB1dWva', '2022-12-09 09:33:06');

-- --------------------------------------------------------

--
-- Table structure for table `appointment`
--

CREATE TABLE `appointment` (
  `id` int(5) NOT NULL,
  `client_id` int(5) NOT NULL,
  `saloon_service_id` varchar(50) NOT NULL,
  `datee` varchar(30) NOT NULL,
  `service_start_time` int(11) NOT NULL,
  `service_end_time` int(11) NOT NULL,
  `emp_id` int(5) NOT NULL,
  `Total_Amount` int(11) NOT NULL,
  `status` int(1) NOT NULL DEFAULT 0 COMMENT '0-unapproved\r\n1-approved',
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp(),
  `approve_time` timestamp NULL DEFAULT NULL,
  `approved_by` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `appointment`
--

INSERT INTO `appointment` (`id`, `client_id`, `saloon_service_id`, `datee`, `service_start_time`, `service_end_time`, `emp_id`, `Total_Amount`, `status`, `timestamp`, `approve_time`, `approved_by`) VALUES
(1, 3, '2', '10/02/2023', 41400, 43200, 2, 150, 1, '2023-02-10 11:30:35', NULL, NULL),
(2, 3, '1', '16/02/2023', 39600, 43200, 1, 100, 1, '2023-02-16 17:00:41', NULL, NULL),
(3, 3, '3', '16/02/2023', 39600, 43200, 3, 130, 1, '2023-02-16 17:32:54', NULL, NULL),
(4, 3, '2', '16/02/2023', 37800, 39600, 1, 150, 1, '2023-02-16 17:33:06', NULL, NULL),
(5, 3, '5,6', '16/02/2023', 39000, 45600, 7, 1050, 0, '2023-02-16 17:33:16', NULL, NULL),
(6, 3, '3', '16/02/2023', 39600, 43200, 3, 130, 1, '2023-02-16 18:12:54', NULL, NULL),
(7, 3, '3', '16/02/2023', 36000, 39600, 3, 130, 1, '2023-02-16 18:16:33', NULL, NULL),
(8, 3, '1', '16/02/2023', 32400, 36000, 4, 100, 0, '2023-02-16 18:17:23', NULL, NULL),
(9, 3, '1', '16/02/2023', 32400, 36000, 1, 100, 1, '2023-02-16 18:18:08', NULL, NULL),
(10, 3, '1,2', '16/02/2023', 37800, 43200, 4, 250, 0, '2023-02-16 18:21:41', NULL, NULL),
(11, 3, '2', '17/02/2023', 36000, 37800, 2, 150, 1, '2023-02-17 16:55:51', NULL, NULL),
(12, 3, '3', '17/02/2023', 39600, 43200, 13, 130, 1, '2023-02-17 17:45:42', NULL, NULL),
(13, 3, '1', '17/02/2023', 32400, 36000, 1, 100, 0, '2023-02-17 18:53:23', NULL, NULL),
(14, 3, '1,2', '17/02/2023', 36000, 39600, 1, 100, 1, '2023-02-17 18:54:52', NULL, NULL),
(15, 1, '1', '12/01/2022', 34000, 36000, 1, 1200, 1, '2023-02-20 10:25:01', NULL, NULL),
(17, 3, '2', '21/02/2023', 36000, 37800, 3, 150, 1, '2023-02-21 13:08:39', NULL, NULL),
(18, 3, '3', '21/02/2023', 32400, 36000, 13, 130, 1, '2023-02-21 13:13:37', NULL, NULL),
(19, 3, '3', '21/02/2023', 39600, 43200, 3, 130, 1, '2023-02-21 13:16:08', NULL, NULL),
(20, 3, '2', '22/02/2023', 36000, 37800, 3, 150, 0, '2023-02-22 11:00:24', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `id` int(5) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(100) NOT NULL,
  `saloon_id` int(5) NOT NULL,
  `pic` varchar(30) NOT NULL,
  `current_status` int(11) NOT NULL DEFAULT 0 COMMENT '0-UnAvailable\r\n1- Available',
  `active` int(1) NOT NULL DEFAULT 1 COMMENT '1-Active\r\n0-UnActive',
  `delete` int(1) NOT NULL DEFAULT 0 COMMENT '0-UnDelete\r\n1-Delete',
  `created_on` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_on` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`id`, `username`, `password`, `saloon_id`, `pic`, `current_status`, `active`, `delete`, `created_on`, `updated_on`) VALUES
(1, 'Ramesh_Babu', 'abcd', 1, 'Ramesh_Babu.jpg', 1, 1, 0, '2023-01-10 05:31:21', '2023-01-10 05:31:21'),
(2, 'Ahmed_Ansari', '12345', 1, 'Ahmed_Ansari.jpg', 1, 1, 0, '2023-01-10 05:31:21', '2023-01-10 05:31:21'),
(3, 'Rajvindar_Singh', '12234edse', 1, 'Rajvindar_Singh.jpg', 1, 1, 0, '2023-01-10 05:32:44', '2023-01-10 05:32:44'),
(4, 'Bharat_Singh', 'sfvdfvb', 2, 'Bharat_Singh.jpg', 1, 1, 0, '2023-01-10 05:32:44', '2023-01-10 05:32:44'),
(6, 'Meet_Mehra', '12345657478', 2, 'Meet_Mehra.jpg', 1, 1, 0, '2023-01-23 05:47:16', '2023-01-23 05:47:16'),
(7, 'Nitesh_Solanki', 'nit2122', 2, 'Nitesh_Solanki.jpg', 1, 1, 0, '2023-01-23 05:47:16', '2023-01-23 05:47:16'),
(9, 'Mohit_Gondaliya', 'mohit12345', 3, 'Mohit_Gondaliya.jpg', 1, 1, 0, '2023-01-23 05:49:33', '2023-01-23 05:49:33'),
(10, 'Sunil_Setty', 'Sunil_Setty12345', 3, 'Sunil_Setty.jpg', 1, 1, 0, '2023-01-23 05:49:33', '2023-01-23 05:49:33'),
(12, 'Harshad_Maheta', 'Harshad_Maheta11234747', 3, 'Harshad_Maheta.jpg', 1, 1, 0, '2023-01-23 05:50:29', '2023-01-23 05:50:29'),
(13, 'mohitmonalisa', '1234', 1, 'mohitmonalisa.jpeg', 1, 1, 0, '2023-02-15 13:26:46', '2023-02-15 13:26:46');

-- --------------------------------------------------------

--
-- Table structure for table `login_attempts`
--

CREATE TABLE `login_attempts` (
  `id` int(11) UNSIGNED NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `login` varchar(100) NOT NULL,
  `time` int(11) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `login_attempts`
--

INSERT INTO `login_attempts` (`id`, `ip_address`, `login`, `time`) VALUES
(9, '::1', 'admin@gmail.com', 1670579018);

-- --------------------------------------------------------

--
-- Table structure for table `review`
--

CREATE TABLE `review` (
  `id` int(5) NOT NULL,
  `user_id` varchar(5) NOT NULL,
  `salon_id` varchar(5) NOT NULL,
  `star` int(5) NOT NULL,
  `comment` varchar(100) DEFAULT NULL,
  `created_on` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_on` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `review`
--

INSERT INTO `review` (`id`, `user_id`, `salon_id`, `star`, `comment`, `created_on`, `updated_on`) VALUES
(1, '1', '01', 5, 'salon provides best services with reasonable prices', '2022-12-27 06:25:08', '2022-12-27 06:25:08');

-- --------------------------------------------------------

--
-- Table structure for table `salon_time`
--

CREATE TABLE `salon_time` (
  `id` int(11) NOT NULL,
  `salon_id` int(11) NOT NULL,
  `Sun_s` int(11) NOT NULL,
  `Sun_e` int(11) NOT NULL,
  `Mon_s` int(11) NOT NULL,
  `Mon_e` int(11) NOT NULL,
  `Tue_s` int(11) NOT NULL,
  `Tue_e` int(11) NOT NULL,
  `Wed_s` int(11) NOT NULL,
  `Wed_e` int(11) NOT NULL,
  `Thu_s` int(11) NOT NULL,
  `Thu_e` int(11) NOT NULL,
  `Fri_s` int(11) NOT NULL,
  `Fri_e` int(11) NOT NULL,
  `Sat_s` int(11) NOT NULL,
  `Sat_e` int(11) NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `salon_time`
--

INSERT INTO `salon_time` (`id`, `salon_id`, `Sun_s`, `Sun_e`, `Mon_s`, `Mon_e`, `Tue_s`, `Tue_e`, `Wed_s`, `Wed_e`, `Thu_s`, `Thu_e`, `Fri_s`, `Fri_e`, `Sat_s`, `Sat_e`, `updated_at`, `created_at`) VALUES
(0, 1, 32400, 75600, 32400, 75600, 32400, 75600, 32400, 75600, 32400, 75600, 32400, 75600, 32400, 75600, '2023-02-17 09:56:16', '2023-01-11 12:10:08'),
(1, 2, 32400, 75600, 32400, 75600, 32400, 75600, 32400, 75600, 32400, 75600, 32400, 75600, 32400, 75600, '2023-01-24 11:24:26', '2023-01-11 12:10:18');

-- --------------------------------------------------------

--
-- Table structure for table `saloon`
--

CREATE TABLE `saloon` (
  `id` int(5) NOT NULL,
  `name` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(100) NOT NULL,
  `desciption` varchar(100) NOT NULL,
  `mail` varchar(30) NOT NULL,
  `logo` varchar(100) NOT NULL,
  `address` varchar(100) NOT NULL,
  `active` int(1) NOT NULL DEFAULT 1 COMMENT '1-active\r\n0-Deactive',
  `map_loc` varchar(100) NOT NULL,
  `mobile` int(10) NOT NULL,
  `current_status` int(1) NOT NULL DEFAULT 0 COMMENT '0-close\r\n1-open',
  `delete` int(1) NOT NULL DEFAULT 0 COMMENT '0-Undelete \r\n1-Delete',
  `create_on` timestamp NOT NULL DEFAULT current_timestamp(),
  `update_on` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `saloon`
--

INSERT INTO `saloon` (`id`, `name`, `username`, `password`, `desciption`, `mail`, `logo`, `address`, `active`, `map_loc`, `mobile`, `current_status`, `delete`, `create_on`, `update_on`) VALUES
(1, 'Chauhan Hair Saloon', 'Sandip', '$2y$10$BNIBej7oUVgzFgoIwA/ByeSbl6ZsbPM6ZaJq9LQ2pgrvS2SAwBmz.', 'best salon in sukhpar please visit', 'a@b.c', 's1.jpg', 'sukhpar, bhuj 370040', 1, '', 121212122, 1, 0, '2022-12-07 09:01:31', '2022-12-07 09:01:31'),
(2, 'Bablu Hair Saloon', 'Bablu', '1234', 'best salon in Mankuva please visit', 'dsddsd@gmai.com', 's2.jpg', 'manukva bhuj 370030', 2, '', 94984844, 1, 0, '2022-12-07 09:01:36', '2022-12-07 09:01:36'),
(3, 'metro salon', 'xyz ', '123456', 'best salon in Bhuj please visit', 'bablu@mail.com', 's3.jpg', 'bhuj kutch 370001', 1, '', 123456789, 0, 0, '2022-12-27 06:39:54', '2022-12-27 06:39:54');

-- --------------------------------------------------------

--
-- Table structure for table `services`
--

CREATE TABLE `services` (
  `id` int(5) NOT NULL,
  `service_name` varchar(50) NOT NULL,
  `desciption` varchar(50) NOT NULL,
  `active` int(1) NOT NULL DEFAULT 1 COMMENT '1=active\r\n0-deactive',
  `delete` int(1) NOT NULL DEFAULT 0 COMMENT '1-de;ete\r\n2-UnDelete',
  `icon` varchar(50) NOT NULL,
  `added_on` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_on` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `services`
--

INSERT INTO `services` (`id`, `service_name`, `desciption`, `active`, `delete`, `icon`, `added_on`, `updated_on`) VALUES
(1, 'Hair Cut', 'Hair Cut service is provided by all salons', 1, 0, 'haircut.png', '2022-12-27 06:48:40', '2023-01-23 05:23:45'),
(2, 'Face Massage', 'Metro_salon provides service by their professional', 1, 0, 'facemassage.png', '2023-01-10 05:37:37', '2023-01-23 05:27:39'),
(3, 'Face Masking', 'Bablu salon is known for face massage', 1, 0, 'facemasking.png', '2023-01-10 05:38:08', '2023-01-23 05:28:29'),
(4, 'Beard Shaving', 'All salon provides this service ', 1, 0, 'beardshaving.png', '2023-01-10 05:39:27', '2023-01-23 05:30:25'),
(5, 'Hair Color', 'All Salons provides this service', 1, 0, 'haircolor.png', '2023-01-10 05:39:53', '2023-01-23 05:30:15'),
(6, 'Hair Iron', 'All Salon Provides this service', 1, 0, 'hairiron.png', '2023-01-10 05:43:05', '2023-01-23 05:30:58');

-- --------------------------------------------------------

--
-- Table structure for table `service_shop`
--

CREATE TABLE `service_shop` (
  `id` int(5) NOT NULL,
  `service_id` int(2) NOT NULL,
  `saloon_id` int(5) NOT NULL,
  `price` int(4) NOT NULL,
  `desc` varchar(200) DEFAULT NULL,
  `service_time` varchar(50) NOT NULL,
  `active` int(1) NOT NULL DEFAULT 1 COMMENT '0-UnActive\r\n1-Active',
  `delete` int(1) NOT NULL DEFAULT 0 COMMENT '0-UnDelete\r\n1-Delete'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `service_shop`
--

INSERT INTO `service_shop` (`id`, `service_id`, `saloon_id`, `price`, `desc`, `service_time`, `active`, `delete`) VALUES
(1, 1, 1, 100, 'one side hair cutting', '60', 1, 0),
(2, 2, 1, 150, 'face massage ', '30', 1, 0),
(3, 3, 1, 130, 'professional babrber\'s', '60', 1, 0),
(5, 1, 2, 100, 'simple hair cut', '60', 1, 0),
(6, 2, 2, 150, 'face massage using normal cream', '30', 1, 0),
(7, 5, 2, 50, 'multiple color and choices', '20', 1, 0),
(8, 6, 2, 1000, 'hair iron using best equipments', '90', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `transaction`
--

CREATE TABLE `transaction` (
  `id` int(5) NOT NULL,
  `appointment_id` int(5) NOT NULL,
  `payment_method` int(5) NOT NULL,
  `amount` int(5) NOT NULL,
  `status` int(1) NOT NULL DEFAULT 0 COMMENT '0-UnConfirm\r\n1-Confirm',
  `transaction_details` varchar(100) NOT NULL COMMENT 'transaction_Id and Other Data',
  `json-formal` varchar(100) NOT NULL COMMENT 'Payment Json Response Text'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `User`
--

CREATE TABLE `User` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(200) NOT NULL,
  `email` varchar(30) NOT NULL,
  `otp` int(6) DEFAULT NULL,
  `status` int(1) NOT NULL COMMENT '0:unverified\r\n1:verified',
  `delete` int(1) NOT NULL DEFAULT 0 COMMENT '0:undelete\r\n1:delete',
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `User`
--

INSERT INTO `User` (`id`, `username`, `password`, `email`, `otp`, `status`, `delete`, `updated_at`, `created_at`) VALUES
(1, 'u539587596_salon', '$2y$10$gpfiXtxT3CLO/Tax9U7vJeUd3bsLHSf.37uO3LioO0v4HzFGkZW7u', 'perixe5374@fsouda.com', 9225, 1, 0, '2023-02-06 09:01:57', '2023-02-01 05:48:40'),
(2, 'jiasdsadgidfasfsddf', '$2y$10$MZFofBjXFCEkN419Lzv70.zj8hgcvmKzVTBgj5iB42IEYnRavRJXe', '20bca024@sanskareducation.org', 1597, 1, 0, '2023-02-06 09:01:53', '2023-02-01 07:43:21'),
(3, 'nitesh', '$2y$10$TilEUWM/kjabzOY/eY.AB.3c5QkAGIRRZYkLNyBlU3v.eI6Eu6/KC', '20bca030@sanskareducation.org', 7963, 0, 0, '2023-02-17 09:37:32', '2023-02-01 07:49:59'),
(4, 's', '$2y$10$migpBq5LeneMDAQLbBZDqe84ifb5fHZVXQnNhyu3BMYtjpWyP0iCm', 'meetbhia3@gmail.com', 7114, 0, 0, '2023-02-21 13:11:20', '2023-02-21 13:11:20'),
(5, 'sd', '$2y$10$/fKxNKj7ib8qaRbfYLJiSehLVuDjUhkZPzaL2yykshgQxvdd0JVQe', 'metbhalodia3@gmail.com', 8453, 0, 0, '2023-02-21 13:13:34', '2023-02-21 13:13:34');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) UNSIGNED NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `username` varchar(100) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `salt` varchar(255) DEFAULT NULL,
  `email` varchar(254) NOT NULL,
  `activation_code` varchar(40) DEFAULT NULL,
  `forgotten_password_code` varchar(40) DEFAULT NULL,
  `forgotten_password_time` int(11) UNSIGNED DEFAULT NULL,
  `remember_code` varchar(40) DEFAULT NULL,
  `created_on` int(11) UNSIGNED NOT NULL,
  `last_login` int(11) UNSIGNED DEFAULT NULL,
  `active` tinyint(1) UNSIGNED DEFAULT NULL,
  `first_name` varchar(50) DEFAULT NULL,
  `last_name` varchar(50) DEFAULT NULL,
  `company` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `ip_address`, `username`, `password`, `salt`, `email`, `activation_code`, `forgotten_password_code`, `forgotten_password_time`, `remember_code`, `created_on`, `last_login`, `active`, `first_name`, `last_name`, `company`, `phone`) VALUES
(1, '127.0.0.1', 'administrator', '$2a$07$SeBknntpZror9uyftVopmu61qg0ms8Qv1yV6FG.kQOSM.9QhmTo36', '', 'admin@admin.com', '', NULL, NULL, NULL, 1268889823, 1670579725, 1, 'Admin', 'istrator', 'ADMIN', '0');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `appointment`
--
ALTER TABLE `appointment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `login_attempts`
--
ALTER TABLE `login_attempts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `review`
--
ALTER TABLE `review`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `salon_time`
--
ALTER TABLE `salon_time`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `saloon`
--
ALTER TABLE `saloon`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `services`
--
ALTER TABLE `services`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `service_shop`
--
ALTER TABLE `service_shop`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `User`
--
ALTER TABLE `User`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(2) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `appointment`
--
ALTER TABLE `appointment`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `employee`
--
ALTER TABLE `employee`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `login_attempts`
--
ALTER TABLE `login_attempts`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `review`
--
ALTER TABLE `review`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `saloon`
--
ALTER TABLE `saloon`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `services`
--
ALTER TABLE `services`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `service_shop`
--
ALTER TABLE `service_shop`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `User`
--
ALTER TABLE `User`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
